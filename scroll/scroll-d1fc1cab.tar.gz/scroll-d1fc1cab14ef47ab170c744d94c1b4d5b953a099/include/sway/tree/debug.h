#ifndef _SWAY_SCENE_DEBUG_H
#define _SWAY_SCENE_DEBUG_H

struct sway_scene_node;

void scene_node_debug_print_info(struct sway_scene_node *node, int x, int y);;

#endif
